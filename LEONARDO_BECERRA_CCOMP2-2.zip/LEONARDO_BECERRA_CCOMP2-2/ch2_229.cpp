#include <iostream>
#include <string>
using namespace std;

int main(){


cout<<"Face length\tSurface area \tVolume"<<endl;
cout<<"of cube(cm)\tof cube(cm^2)\tof cube(cm^3)"<<endl;
cout<<"                                         "<<endl;
cout<<"0"<<"\t\t"<<0*0*6<<"\t\t"<<0*0*0<<endl; 
cout<<"1"<<"\t\t"<<1*1*6<<"\t\t"<<1*1*1<<endl;       
cout<<"2"<<"\t\t"<<2*2*6<<"\t\t"<<2*2*2<<endl;
cout<<"3"<<"\t\t"<<3*3*6<<"\t\t"<<3*3*3<<endl;
cout<<"4"<<"\t\t"<<4*4*6<<"\t\t"<<4*4*4<<endl;

    return 0;
}